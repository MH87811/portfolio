# Persian copywriting pass: report

Project: `portfolio` (Django). Scope: every user-visible Persian string. **No database record, schema or migration was touched.**

## 1. Files changed

| File | Change |
|---|---|
| `app/static/i18n.js` | Whole Persian dictionary rewritten (295 keys) in the agreed tone and glossary. New keys (EN and FA): `btn.more`, `btn.less`, `contact.n4`, `contact.ledeTg`, `ch.TELEGRAM`, `ch.quick`, `btn.telegram`, `about.contactGlanceTg`, `kind.*` (technology kinds). Existing English values are unchanged. |
| `app/static/data.js` | `CONFIG.telegram = 'https://t.me/Mr87811'`. Persian overlay replaced with your copy: About intro, two body paragraphs, four principles, hero/About lines (`COPY`), learning state legend, availability line. |
| `app/static/app.js` | (a) Telegram contact card, shown first, with its own button label «پیام در تلگرام». (b) "Read more" / "Show less" were hard-coded English; now from the dictionary. (c) Stack group headings and inspector labels (language, framework, database…) were raw English in Persian mode; now localized. (d) Lower-casing of display names is English-only, so Persian shows "Django", not "django". (e) Command-palette hint for pages uses the route path (identical in English; avoids the same Persian word twice). |
| `app/templates/index.html` | Persian `<noscript>` sentence. |
| `app/templates/404.html` | Its own copy of the Persian dictionary synced with `i18n.js`. |
| `staticfiles/app.js`, `data.js`, `i18n.js` | Copied from `app/static` (the two trees were byte-identical before I started, so no ambiguity; `collectstatic` was not run). |
| `persian-db-proposals.json` (new) | Proposed Persian values for all database-backed records. Not applied anywhere. |
| `PERSIAN-COPY-REPORT.md` (new) | This file. |

Not changed: `models.py`, `views.py`, `admin.py`, migrations, `db.sqlite3`, `portfolio-copy-review.json` (your export), CSS.

## 2. Copy coverage

Reviewed: navigation and breadcrumbs, rail, status bar, hero, About (intro, principles, glance, key-value block), projects list and case-study pages (all section labels, ADR/trade-off labels, buttons, aria-labels), Stack, Learning (states, groups, empty states), Lab (search, filters, counts, empty and no-match states, note pages, figure captions), Contact, command palette (placeholder, hints, result types, empty/count messages), graph inspector, mobile tree, language notice, back-to-top, 404, `<noscript>`, document titles, all `aria-label` and `placeholder` values. Hard-coded strings in `app.js` and the templates were searched for separately. CSS has only two decorative `content:` values (`$ `, ` ↗`), both language neutral.

Fixes beyond wording: `about.progress` and `insp.counts` put a middle dot before a Persian digit, which reads as a zero (the code already avoids this elsewhere); both now use a dash or Persian comma.

Terminology follows your glossary: درباره من، پروژه‌ها، فناوری‌ها، مسیر یادگیری، آزمایشگاه، ارتباط، معماری، تصمیم‌های فنی، چالش‌ها، نتیجه، محدودیت‌ها، مخزن کد، در حال انجام، تکمیل‌شده، نمونه اولیه، جست‌وجو، پاک کردن فیلترها، نتیجه‌ای پیدا نشد، برگشت به بالای صفحه، بعدی/قبلی. Where your glossary was silent I chose: project `active` → «در حال توسعه»; learning states → در حال آشنایی / یادگیری / مطالعه / ساخت; `queued` → «در صف».

## 3. Persian strings still missing (shown in English in Persian mode)

All of these are **database-backed**. They stay English until you paste the values from `persian-db-proposals.json` into the `*_fa` admin fields. (The view sends the English text as a fallback, so a `data.js` overlay cannot replace them; I did not change `views.py`.)

- Categories (4): `name_fa`, `description_fa`.
- Technologies (24): `description_fa` (all 24 are English or empty); `name_fa` only for 4 generic names.
- Projects (4): `title_fa`, `kind_fa`, `description_fa`, and `detail_fa` (all English or placeholder).
- Learning items (3): `title_fa`, `description_fa`.
- Lab: `tst-lab` is a placeholder, intentionally left untranslated.

Also English by design (technical values): `language_stack` strings (`Golang · Gin`), slugs, URLs, email, the Latin technology lines in the About key-value block (`app.js`).

There is **no `<meta name="description">`** in `index.html`, so there is nothing to localize. Because language is switched by JavaScript, a per-language meta description would need server rendering. Suggested text if you want one: «توسعه‌دهنده بک‌اند؛ پروژه‌ها، فناوری‌ها و یادداشت‌های فنی مازیار حیدری.»

## 4. Database content review

`persian-db-proposals.json`: one entry per record (by slug) with `status` = `ready` or `confirm`, evidence, and notes. Includes placeholder detail and replacement proposals (English and Persian), suggested English typo fixes, and visibility findings. Highlights:

- **Placeholder text is live on the English site today.** `laravel-auth` shows a body copied from another project ("Why Redis", `channel_layer.group_send`); `django-market` shows "A concise project overview.", "Use PostgreSQL / Why this option was selected." and a Database: PostgreSQL line that contradicts its technology list (SQLite); `django-chat` holds a template in a `blocks` key the site ignores.
- `tst-lab` ("test lab" / "testingl bab") is public in Lab and in the palette. I did not translate it. Your Laravel debugging note is proposed as a **new** entry, not a replacement, because `tst-lab` is tagged Python only.
- Technologies `go`, `gin`, `jwt`, `auth`, `jinja` are **inactive**, so the Go/Gin project shows only PostgreSQL and Stack has no Go row.

## 5. Uncertain content: please confirm

1. **gin-auth and laravel-auth** claims (rotation, revocation, hashed tokens, database-backed sessions…) come from your own English descriptions. Neither record has a repository URL, so I could not check code. Your draft Persian hedged these ("being examined"); the English says they exist, so the Persian follows the English.
2. **django-market**: your draft mentions cart, orders and buyer/seller roles. Nothing in the export supports that, so the proposed text is limited to the description and stack. Your draft is kept in the file as an option.
3. The architecture tiers in my `detail` proposals group components you named; the grouping is mine.
4. **Contact**: Telegram is shown first and the intro now says to use Telegram. In English this changed copy that said "Email is the fastest" (only when the Telegram link is present). The About glance line also lists Telegram. Revert in `data.js` (remove `telegram`) to restore the old English exactly. I did not say Telegram is always available.
5. `status` of both auth projects is "completed" in the export; I kept it.
6. About page lines (`app.js`) list MySQL and Gin; neither matches the technology records. Not changed.
7. The Persian name «مازیار حیدری» in the About glance is my transliteration of the Latin name.
8. Persian tone is conversational (می‌تونی، می‌شه) in sentences and neutral in short labels.

## 6. Verification (what was actually run)

- `node --check` on `app.js`, `data.js`, `i18n.js`: pass.
- `python3 -m py_compile` on `views.py`, `models.py`, `admin.py`, `settings.py`, `urls.py`: pass (no Python file was edited).
- `git diff --check`: pass.
- Dictionary script: every English key has a Persian key (except the intentional `copy.*`), identical `{placeholders}`, no Arabic yeh/kaf, no missing ZWNJ after «می», no space before «ها», no middle dot before Persian digits: pass.
- jsdom render of all 13 routes (home, About, Projects, Stack, Learning, Lab, Contact, 404 route, 4 project pages, 1 note) in fa and en, using data built from your JSON export by a Python mirror of `views.py` (no database): no JavaScript errors. English output is identical to the original code's output except the Telegram additions. Persian output has no leftover English except machine values (URLs, slugs, email), Latin product names, and the `tst-lab` placeholder, both with today's data and with the proposals applied in memory.
- `404.html` Persian strings match `i18n.js` (script comparison).

**Not run:** `manage.py check`/tests (`tests.py` is empty; I avoided anything that opens a database); a real browser, so RTL layout, Vazirmatn rendering, mobile layout and keyboard behavior were not visually checked. Please open the site once in Persian on desktop and phone.

## 7. Database safety confirmation

No database records, schema or migrations were modified. `db.sqlite3` was never opened; its SHA-256 (`93ccfe7a…15f410f0`) is identical before and after, and byte-identical to the file in your ZIP. No migration was generated or run. All database-backed copy is in `persian-db-proposals.json` for you to apply by hand.
